# Vaddarapu Ajay — Portfolio Website

A responsive personal portfolio website for **Vaddarapu Ajay**, a **B.Tech CSE AIML** student at **Sandip University** (currently in the **2nd year** year), with a stated career goal of becoming an **AI engineer**.

## Included sections
- Home and About
- Skills: HTML, JAVA, C
- Projects: Smart Dustbin and Supermarket Sales Analysis
- Education
- Achievements & Certifications
- Experience
- Resume starter template
- Contact: vaddarapuajay7@gmail.com and GitHub

## Tech stack
- HTML5
- CSS3 (responsive layout, theme variables, mobile navigation)
- Vanilla JavaScript (navigation toggle, light/dark theme toggle, current year)

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. For a local development server, open the folder in VS Code and use an available static server extension, or run `python -m http.server 8000` from this directory and visit `http://localhost:8000`.

## Personal links
- GitHub profile: https://github.com/ajay263311
- Email: vaddarapuajay7@gmail.com
- LinkedIn: Not provided.

## Important content checklist before submission
This project intentionally does **not** invent missing details.
- [ ] Replace the third-project placeholder with a real third project if your assignment requires at least three projects.
- [ ] Add each project's actual description, technologies used, screenshots, and direct source repository link.
- [ ] Add verified achievements/certifications if applicable.
- [ ] Add internship/work experience if applicable; otherwise state that you have no formal experience yet, if accurate.
- [ ] Add education dates and prior education only if you want them included.
- [ ] Review and complete `docs/Resume_Template.docx`.
- [ ] Review `docs/Project_Documentation.docx`.
- [ ] Test mobile layout and links.

## Publish on GitHub
1. Create a repository on GitHub named `ajay-portfolio` (or another name you prefer).
2. Upload the contents of this folder, including `index.html`, `styles.css`, `script.js`, `assets/`, and `docs/`.
3. Add a repository description and commit the files.
4. The public repository URL should use your actual GitHub username and repository name; verify it after publishing.

## Deploy on Vercel
1. Sign in to Vercel and import the GitHub repository.
2. Choose the project repository.
3. For this static site, no build command is needed; the output can be the project root.
4. Deploy and test the generated URL on desktop and mobile.
5. Add the real deployed URL to your README and assignment submission after deployment.

**Status:** This ZIP is a local project starter. It has not been published to GitHub or deployed to Vercel by this file-generation step.
